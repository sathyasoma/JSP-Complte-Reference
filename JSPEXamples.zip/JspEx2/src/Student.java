import java.io.Serializable;
public class Student  implements Serializable
{
private int stid;
private String name;
private String add;
public int getStid() {
	return stid;
}
public void setStid(int stid) {
	this.stid = stid;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getAdd() {
	return add;
}
public void setAdd(String add) {
	this.add = add;
}
}
